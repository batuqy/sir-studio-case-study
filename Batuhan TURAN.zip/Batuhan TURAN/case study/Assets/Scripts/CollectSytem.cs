using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollectSytem : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        ScoreSytem.Score +=10;
        Destroy(gameObject);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Completed : MonoBehaviour
{
    

    // Update is called once per frame
    void Update()
    {
        if (ScoreSytem.Score==100)
        {
            SceneManager.LoadScene("FinalScene");
        }    
    }
}

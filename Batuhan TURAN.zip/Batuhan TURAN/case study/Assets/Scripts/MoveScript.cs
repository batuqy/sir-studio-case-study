using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveScript : MonoBehaviour
{
    public CharacterController controller;
    public float speed=12f;
    void FixedUpdate()
    {

        Movement();

    }
    void Movement()
    {

        float x = Input.GetAxis("Horizontal") * speed * Time.deltaTime;
        float z = Input.GetAxis("Vertical") * speed * Time.deltaTime;
        Vector3 move =transform.forward * z;
        controller.Move(move * speed * Time.deltaTime);
        transform.Rotate(0, x, 0);
    }
}

using UnityEngine;
using EasyJoystick; //line added

public class JoystickMove : MonoBehaviour
{

    [SerializeField] private float speed;
    [SerializeField] private Joystick joystick; //line added
    public CharacterController controller;
    void FixedUpdate()
    {
        Movement();


    }
    void Movement()
    {

        float xMovement = joystick.Horizontal(); //line changed
        float zMovement = joystick.Vertical();   //line changed
        Vector3 move = transform.forward * zMovement;
        controller.Move(move * speed * Time.deltaTime);
        transform.Rotate(0, xMovement, 0);
    }

}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomSpawner : MonoBehaviour
{
    public GameObject SpawnObject;
    private float xPos;
    private float zPos;
    public int counter;
    // Update is called once per frame
    void Start()
    {
        StartCoroutine(spawner());
        
    }
  
    IEnumerator spawner()
    {
        while (counter < 30)
        {
            xPos = Random.Range(-5, 5);
            zPos = Random.Range(-5, 5);
            Instantiate(SpawnObject, new Vector3(xPos, 1, zPos), Quaternion.identity);
            yield return new WaitForSeconds(5);
            counter += 1;
        }

    }


}
